package com.ims.jpgtosketsa

import android.graphics.*
import android.media.*
import java.io.File
import kotlin.math.*
import kotlin.random.Random

class PaintOptions(
    val style: Int = 0,       // 0 sketsa lalu warna, 1 langsung warna, 2 sketsa saja
    val direction: Int = 0,   // 0 kiri-kanan, 1 atas-bawah, 2 tengah keluar
    val paper: Int = 0,       // 0 putih, 1 krem, 2 papan tulis
    val ratio: Int = 0,       // 0 sesuai foto, 1 9:16, 2 1:1, 3 16:9
    val res: Int = 720,       // sisi terpanjang
    val handPct: Int = 55,    // lebar tangan, % dari lebar video
    val handSpeed: Float = 1f,
    val holdSec: Int = 1,
    val fps: Int = 30,
    val sens: Int = 0,        // 0 otomatis, 1 lebih sedikit garis, 2 lebih banyak
    val thick: Int = 0,       // 0 otomatis, 1 tipis, 2 sedang, 3 tebal
    val source: Int = 0,      // 0 otomatis, 1 tepi (foto), 2 area gelap (gambar hitam-putih)
    val ink: Int = 0,         // 0 otomatis, 1 biru tua, 2 cokelat sepia, 3 abu pensil, 4 warna asli
    val transparentSrc: Boolean = false   // sumber = sketsa PNG transparan (hanya garis)
)

object SpeedPaint {
    private val PAPER = intArrayOf(0xFFFFFFFF.toInt(), 0xFFF5ECD7.toInt(), 0xFF2B3A33.toInt(), 0xFFF3EFE0.toInt())
    private val INK = intArrayOf(0xFF222222.toInt(), 0xFF3A2E1E.toInt(), 0xFFF2F2F2.toInt(), 0xFF222222.toInt())
    private val INK2 = intArrayOf(0xFF888888.toInt(), 0xFF8C7F68.toInt(), 0xFF9AA39E.toInt(), 0xFF888888.toInt())

    fun render(
        src: Bitmap, seconds: Int, out: File, o: PaintOptions, hand: Bitmap?,
        cancelled: () -> Boolean, onProgress: (Int) -> Unit
    ) {
        val fps = o.fps
        val total = seconds * fps
        val r = o.res
        val (w0, h0) = when (o.ratio) {
            1 -> Pair(r * 9 / 16, r)
            2 -> Pair(r, r)
            3 -> Pair(r, r * 9 / 16)
            else -> {
                val sc = r.toFloat() / max(src.width, src.height)
                Pair((src.width * sc).toInt(), (src.height * sc).toInt())
            }
        }
        val w = w0 and 1.inv()
        val h = h0 and 1.inv()
        val n = w * h

        // Kanvas kertas + foto di tengah
        val canvasBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val bc = Canvas(canvasBmp)
        drawPaper(bc, w, h, o.paper)
        val paperImg = IntArray(n).also { canvasBmp.getPixels(it, 0, w, 0, 0, w, h) }
        val s = min(w.toFloat() / src.width, h.toFloat() / src.height)
        val dw = src.width * s
        val dh = src.height * s
        val dst = RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2)
        val pPhoto = Paint(Paint.FILTER_BITMAP_FLAG)
        // Foto dilebur ke kertas (multiply): bagian terang foto menampilkan kertas beserta garisnya
        if (o.paper != 2) pPhoto.xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
        bc.drawBitmap(src, null, dst, pPhoto)
        val color = IntArray(n).also { canvasBmp.getPixels(it, 0, w, 0, 0, w, h) }
        canvasBmp.recycle()
        // Versi polos (foto di atas putih) untuk deteksi garis, agar garis kertas tidak ikut terdeteksi
        val pb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pc = Canvas(pb)
        pc.drawColor(Color.WHITE)
        pc.drawBitmap(src, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        val plain = IntArray(n).also { pb.getPixels(it, 0, w, 0, 0, w, h) }
        pb.recycle()
        val transp = o.transparentSrc
        val alphaArr = if (transp) {
            val ab = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(ab).drawBitmap(src, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            val arr = IntArray(n)
            ab.getPixels(arr, 0, w, 0, 0, w, h)
            ab.recycle()
            IntArray(n) { arr[it] ushr 24 }
        } else IntArray(0)

        // Urutan reveal sesuai arah
        val cx = w / 2f
        val cy = h / 2f
        val maxd = hypot(cx, cy)
        val buckets = 2000
        val key = IntArray(n) { i ->
            val x = i % w
            val y = i / w
            val b = when (o.direction) {
                1 -> y.toFloat() / h
                2 -> hypot(x - cx, y - cy) / maxd
                else -> x.toFloat() / w
            }
            ((b * 0.85f + Random.nextFloat() * 0.15f) * (buckets - 1)).toInt()
        }
        val cnt = IntArray(buckets + 1)
        for (k in key) cnt[k + 1]++
        for (i in 0 until buckets) cnt[i + 1] += cnt[i]
        val order = IntArray(n)
        for (i in 0 until n) order[cnt[key[i]]++] = i

        // Penelusuran garis: urutan piksel mengikuti goresan
        val useSeq = o.style != 1
        val rx0 = ((w - dw) / 2f).toInt().coerceIn(0, w - 1)
        val ry0 = ((h - dh) / 2f).toInt().coerceIn(0, h - 1)
        val rx1 = ((w + dw) / 2f).toInt().coerceIn(rx0 + 1, w)
        val ry1 = ((h + dh) / 2f).toInt().coerceIn(ry0 + 1, h)
        val dark = useSeq && !transp && when (o.source) {
            1 -> false
            2 -> true
            else -> isLineArt(plain, w, rx0, ry0, rx1, ry1)
        }
        val mask = when {
            !useSeq -> BooleanArray(0)
            transp -> BooleanArray(n) { alphaArr[it] > 30 }
            dark -> darkMask(plain, w, h, rx0, ry0, rx1, ry1, o.sens)
            else -> edgeMask(plain, w, h, o.sens)
        }
        if (useSeq && !dark && !transp) clipMask(mask, w, h, rx0, ry0, rx1, ry1, 3)
        var inkCount = 0
        for (m in mask) if (m) inkCount++
        val frac = inkCount.toFloat() / n
        val br = if (transp) 0 else when (o.thick) {
            1 -> 0
            2 -> 1
            3 -> 2
            else -> {
                if (dark) 0 else {
                    var r0 = (max(w, h) / 540f).roundToInt()
                    if (frac > 0.10f) r0 -= 1
                    if (frac < 0.03f) r0 += 1
                    r0.coerceIn(0, 2)
                }
            }
        }
        val seq = if (useSeq) traceStrokes(mask, w, h, order) else IntArray(0)
        val inkFixed = when {
            o.paper == 2 && o.ink in 1..3 -> INK[2]
            o.ink == 1 -> 0xFF1F2A8C.toInt()
            o.ink == 2 -> 0xFF5A3A22.toInt()
            o.ink == 3 -> 0xFF4A4A4A.toInt()
            else -> INK[o.paper]
        }
        fun inkAt(p: Int): Int = when {
            transp && (o.ink == 0 || o.ink == 4) -> color[p]
            transp -> blend(paperImg[p], inkFixed, alphaArr[p])
            o.ink == 4 -> plain[p]
            else -> inkFixed
        }
        val sketchFinal = paperImg.copyOf()
        for (p in seq) stamp(sketchFinal, p, w, h, br, inkAt(p))
        val fillMode = o.style == 3
        val trace = if (fillMode) growFill(seq, w, h, order) else seq

        val cur = paperImg.copyOf()
        val frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val hs = hand?.let {
            val hw = max(8, (w * o.handPct / 100f).toInt())
            Bitmap.createScaledBitmap(it, hw, max(1, it.height * hw / it.width), true)
        }

        // Encoder
        val fmt = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, (if (max(w, h) >= 1000) 8_000_000 else 4_000_000) * (if (fps > 30) 3 else 2) / 2)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType("video/avc")
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = codec.createInputSurface()
        codec.start()
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var outCount = 0L
        val info = MediaCodec.BufferInfo()

        fun drain(eos: Boolean) {
            if (eos) codec.signalEndOfInputStream()
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!eos) return
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(codec.outputFormat); muxer.start()
                    }
                    i >= 0 -> {
                        val buf = codec.getOutputBuffer(i)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0) {
                            info.presentationTimeUs = outCount++ * 1_000_000L / fps
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            muxer.writeSampleData(track, buf, info)
                        }
                        codec.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }

        val hold = min(o.holdSec * fps, total / 2)
        val s2 = max(2, total - hold)                 // frame terakhir menggambar
        val half = if (o.style == 0) max(1, s2 * 65 / 100) else s2   // akhir fase garis
        val finalImg = if (o.style == 2) sketchFinal else color
        var rev = 0
        var hx = 0f
        var hy = 0f
        var started = false

        try {
            for (f in 0 until total) {
                if (cancelled()) break
                var drawing = true
                val tt = f * 30f / fps
                if (o.style == 0 && f == half) rev = 0
                val from = rev
                var tx = hx
                var ty = hy
                var fresh = false
                if (f < s2) {
                    val inFirst = f < half
                    val start = if (inFirst) 0 else half
                    val len = if (inFirst) half else s2 - half
                    if (inFirst && useSeq) {
                        val t = (trace.size.toLong() * (f - start + 1) / len).toInt()
                        for (j in rev until t) {
                            val p = trace[j]
                            if (fillMode) cur[p] = color[p] else stamp(cur, p, w, h, br, inkAt(p))
                        }
                        rev = t
                        if (rev > from) { val idx = trace[rev - 1]; tx = (idx % w).toFloat(); ty = (idx / w).toFloat(); fresh = true }
                    } else {
                        val t = (n.toLong() * (f - start + 1) / len).toInt()
                        for (j in rev until t) cur[order[j]] = color[order[j]]
                        rev = t
                        if (rev > from) {
                            val k = min(rev - from, 50)
                            val step = max(1, (rev - from) / k)
                            var sx = 0L
                            var sy = 0L
                            for (q in 0 until k) {
                                val idx = order[rev - 1 - q * step]
                                sx += idx % w
                                sy += idx / w
                            }
                            var px = sx.toFloat() / k
                            var py = sy.toFloat() / k
                            val wob = sin(tt * 0.9f * o.handSpeed)
                            when (o.direction) {
                                1 -> px = w * (0.5f + 0.4f * wob)
                                2 -> {
                                    val rad = (rev.toFloat() / n) * maxd * 0.8f
                                    val a2 = tt * 0.35f * o.handSpeed
                                    px = cx + rad * cos(a2)
                                    py = cy + rad * sin(a2)
                                }
                                else -> py = h * (0.5f + 0.4f * wob)
                            }
                            tx = px; ty = py; fresh = true
                        }
                    }
                } else {
                    drawing = false
                    System.arraycopy(finalImg, 0, cur, 0, n)
                }
                if (fresh) {
                    if (!started) { hx = tx; hy = ty; started = true }
                    else { val k2 = 0.45f * o.handSpeed.coerceAtMost(2f) * 30f / fps; hx += (tx - hx) * k2.coerceAtMost(1f); hy += (ty - hy) * k2.coerceAtMost(1f) }
                }
                frame.setPixels(cur, 0, w, 0, 0, w, h)
                val c = surface.lockCanvas(null)
                c.drawBitmap(frame, 0f, 0f, null)
                if (hs != null && drawing && started) {
                    c.drawBitmap(hs, hx.coerceIn(0f, w.toFloat()), hy - 0.96f * hs.height, null)
                }
                surface.unlockCanvasAndPost(c)
                drain(false)
                onProgress(f * 100 / total)
            }
            drain(true)
        } finally {
            codec.stop(); codec.release()
            if (track >= 0) muxer.stop()
            muxer.release(); surface.release()
        }
    }

    private fun grayOf(c: Int) = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10

    /** Gambar hampir tanpa warna (hitam-putih/abu-abu) dianggap line-art. */
    private fun isLineArt(px: IntArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int): Boolean {
        var gray = 0L
        var all = 0L
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = px[y * w + x]
                val mx = max(Color.red(c), max(Color.green(c), Color.blue(c)))
                val mn = min(Color.red(c), min(Color.green(c), Color.blue(c)))
                if (mx - mn < 24) gray++
                all++
                x += 3
            }
            y += 3
        }
        return all > 0 && gray.toDouble() / all > 0.96
    }

    /** Area gelap sebagai tinta (Otsu pada kecerahan), termasuk bagian hitam penuh. */
    private fun darkMask(px: IntArray, w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int, sens: Int): BooleanArray {
        val hist = IntArray(256)
        for (y in y0 until y1) for (x in x0 until x1) hist[grayOf(px[y * w + x])]++
        val tot = ((x1 - x0).toLong() * (y1 - y0).toLong())
        var sumAll = 0L
        for (t in 0 until 256) sumAll += t.toLong() * hist[t]
        var wB = 0L
        var sumB = 0L
        var best = -1.0
        var thr = 100
        for (t in 0 until 256) {
            wB += hist[t]
            if (wB == 0L) continue
            val wF = tot - wB
            if (wF <= 0L) break
            sumB += t.toLong() * hist[t]
            val mB = sumB.toDouble() / wB
            val mF = (sumAll - sumB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; thr = t }
        }
        thr = thr.coerceIn(40, 128)
        if (sens == 1) thr = (thr * 0.75f).toInt()
        if (sens == 2) thr = min(160, (thr * 1.25f).toInt())
        val mask = BooleanArray(w * h)
        for (y in y0 until y1) for (x in x0 until x1) mask[y * w + x] = grayOf(px[y * w + x]) < thr
        return mask
    }

    /** Peta garis tepi dengan ambang otomatis (Otsu pada gradien), disesuaikan agar jumlah garis wajar. */
    private fun edgeMask(px: IntArray, w: Int, h: Int, sens: Int): BooleanArray {
        val g0 = IntArray(w * h) { (Color.red(px[it]) * 3 + Color.green(px[it]) * 6 + Color.blue(px[it])) / 10 }
        val g = IntArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            g[i] = (g0[i - w - 1] + g0[i - w] + g0[i - w + 1] + g0[i - 1] + g0[i] + g0[i + 1] + g0[i + w - 1] + g0[i + w] + g0[i + w + 1]) / 9
        }
        val mag = ShortArray(w * h)
        val hist = IntArray(1024)
        for (y in 2 until h - 2) for (x in 2 until w - 2) {
            val i = y * w + x
            val gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            val m = min(1023, abs(gx) + abs(gy))
            mag[i] = m.toShort()
            hist[m]++
        }
        val tot = ((w - 4).toLong() * (h - 4).toLong())
        var sumAll = 0L
        for (t in 0 until 1024) sumAll += t.toLong() * hist[t]
        var wB = 0L
        var sumB = 0L
        var best = -1.0
        var thr = 80
        for (t in 0 until 1024) {
            wB += hist[t]
            if (wB == 0L) continue
            val wF = tot - wB
            if (wF <= 0L) break
            sumB += t.toLong() * hist[t]
            val mB = sumB.toDouble() / wB
            val mF = (sumAll - sumB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; thr = t }
        }
        fun fracAbove(t: Int): Double {
            var c = 0L
            for (i in t + 1 until 1024) c += hist[i]
            return c.toDouble() / tot
        }
        thr = thr.coerceIn(40, 250)
        while (thr < 600 && fracAbove(thr) > 0.12) thr += 5
        while (thr > 25 && fracAbove(thr) < 0.015) thr -= 5
        if (sens == 1) thr = (thr * 1.6f).toInt()
        if (sens == 2) thr = max(20, (thr * 0.6f).toInt())
        val mask = BooleanArray(w * h)
        for (i in 0 until w * h) mask[i] = mag[i] > thr
        return mask
    }

    /** Kertas polos, atau kertas buku bergaris dengan lubang di kiri. */
    private fun drawPaper(c: Canvas, w: Int, h: Int, paper: Int) {
        c.drawColor(PAPER[paper])
        if (paper != 3) return
        val sp = max(16f, h / 32f)
        val line = Paint().apply { color = 0xFFB9BFCC.toInt(); strokeWidth = max(1f, w / 600f) }
        var y = sp * 3.2f
        while (y < h - sp * 0.5f) {
            c.drawLine(w * 0.07f, y, w * 0.97f, y, line)
            y += sp
        }
        val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE9EAEE.toInt() }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = 0xFFC9CCD4.toInt(); strokeWidth = max(1f, w / 500f)
        }
        var hy = sp * 3.2f
        while (hy < h - sp) {
            c.drawCircle(w * 0.028f, hy, w * 0.017f, hole)
            c.drawCircle(w * 0.028f, hy, w * 0.017f, ring)
            hy += sp * 1.7f
        }
    }

    private fun clipMask(m: BooleanArray, w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int, pad: Int) {
        for (y in 0 until h) {
            val o = y * w
            val inY = y >= y0 + pad && y < y1 - pad
            for (x in 0 until w) if (!(inY && x >= x0 + pad && x < x1 - pad)) m[o + x] = false
        }
    }

    /** Urutan isi: goresan dulu, lalu warna merambat keluar dari garis (BFS). */
    private fun growFill(seq: IntArray, w: Int, h: Int, fallback: IntArray): IntArray {
        if (seq.isEmpty()) return fallback
        val n = w * h
        val q = IntArray(n)
        val seen = BooleanArray(n)
        var tail = 0
        for (p in seq) { q[tail++] = p; seen[p] = true }
        var head = 0
        while (head < tail) {
            val p = q[head++]
            val x = p % w
            if (x > 0 && !seen[p - 1]) { seen[p - 1] = true; q[tail++] = p - 1 }
            if (x < w - 1 && !seen[p + 1]) { seen[p + 1] = true; q[tail++] = p + 1 }
            if (p >= w && !seen[p - w]) { seen[p - w] = true; q[tail++] = p - w }
            if (p < n - w && !seen[p + w]) { seen[p + w] = true; q[tail++] = p + w }
        }
        return if (tail == n) q else fallback
    }

    private fun blend(bg: Int, fg: Int, a: Int): Int {
        val t = a / 255f
        val r = (Color.red(bg) * (1 - t) + Color.red(fg) * t).toInt()
        val g = (Color.green(bg) * (1 - t) + Color.green(fg) * t).toInt()
        val b = (Color.blue(bg) * (1 - t) + Color.blue(fg) * t).toInt()
        return Color.rgb(r, g, b)
    }

    private fun stamp(a: IntArray, p: Int, w: Int, h: Int, r: Int, c: Int) {
        val x = p % w
        val y = p / w
        for (dy in 0..r) {
            val yy = y + dy
            if (yy >= h) break
            for (dx in 0..r) {
                val xx = x + dx
                if (xx >= w) break
                a[yy * w + xx] = c
            }
        }
    }

    /** Menelusuri garis: urutan piksel mengikuti arah goresan (DFS lurus-dulu). */
    private fun traceStrokes(mask: BooleanArray, w: Int, h: Int, order: IntArray): IntArray {
        val n = w * h
        var ink = 0
        for (b in mask) if (b) ink++
        val seq = IntArray(ink)
        var sl = 0
        val visited = BooleanArray(n)
        val stackP = IntArray(8 * ink + 16)
        val stackD = IntArray(8 * ink + 16)
        val dxs = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)
        val dys = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)
        val cand = IntArray(8)
        val score = IntArray(8)
        for (start in order) {
            if (!mask[start] || visited[start]) continue
            val compStart = sl
            var sp = 0
            stackP[0] = start; stackD[0] = start; sp = 1
            while (sp > 0) {
                sp--
                val p = stackP[sp]
                val par = stackD[sp]
                if (visited[p]) continue
                visited[p] = true
                seq[sl++] = p
                val x = p % w
                val y = p / w
                val ddx = x - par % w
                val ddy = y - par / w
                var c = 0
                for (k in 0 until 8) {
                    val nx = x + dxs[k]
                    val ny = y + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val q = ny * w + nx
                    if (!mask[q] || visited[q]) continue
                    val sc = dxs[k] * ddx + dys[k] * ddy
                    var i = c
                    while (i > 0 && score[i - 1] > sc) { score[i] = score[i - 1]; cand[i] = cand[i - 1]; i-- }
                    score[i] = sc; cand[i] = q; c++
                }
                for (i in 0 until c) { stackP[sp] = cand[i]; stackD[sp] = p; sp++ }
            }
            if (sl - compStart < 15) sl = compStart   // buang bintik noise
        }
        return seq.copyOf(sl)
    }
}
